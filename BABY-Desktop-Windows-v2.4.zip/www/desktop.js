const root = document.documentElement;
const element = (id) => document.getElementById(id);
export const desktopBridge = window.chrome?.webview;
const motions = new Set(["idle", "wave", "walk", "dance"]);
let pendingReference = null;
let referenceChanged = () => {};
let motionTimer = 0;

export function sendDesktop(action, value) {
  if (!desktopBridge) return;
  desktopBridge.postMessage({ action, value });
}

function renderReference() {
  const chip = element("desktop-reference");
  const label = element("desktop-reference-name");
  chip.hidden = pendingReference === null;
  label.textContent = pendingReference?.title ?? "";
  element("desktop-reference-review").title = pendingReference ? "Review " + pendingReference.title : "";
  referenceChanged();
}

export function hasDesktopReference() {
  return Boolean(pendingReference?.text);
}

export function takeDesktopReference() {
  const reference = pendingReference;
  clearDesktopReference();
  return reference;
}

export function clearDesktopReference() {
  if (!pendingReference) return;
  pendingReference = null;
  renderReference();
}

export function setDesktopConnection({ connected = false, requiresSignIn = false, attachments } = {}) {
  const button = element("desktop-connection-state");
  const label = element("desktop-connection-label");
  button.dataset.connection = connected ? "online" : requiresSignIn ? "signin" : "offline";
  label.textContent = connected ? "Connected" : requiresSignIn ? "Sign in" : "Connection";
  button.title = connected ? "Manage the BABY connection" : requiresSignIn ? "Sign in to hosted BABY" : "Connect to BABY";
  if (typeof attachments === "boolean") {
    root.dataset.binaryAttachments = String(attachments);
  }
}

function setPetSize(size) {
  const range = element("desktop-pet-size");
  const value = Number(size);
  if (!Number.isFinite(value)) return;
  const min = Number(range.min);
  const max = Number(range.max);
  const safe = Math.max(min, Math.min(max, Math.round(value / 5) * 5));
  range.value = String(safe);
  element("desktop-size-value").textContent = range.value + "%";
  range.style.setProperty("--desktop-range-progress", ((safe - min) / (max - min) * 100) + "%");
}

function setMotion(motion, transmit = true) {
  if (!motions.has(motion)) return;
  clearTimeout(motionTimer);
  root.dataset.petMotion = motion;
  window.dispatchEvent(new CustomEvent("baby:pet-motion", { detail: { motion } }));
  if (transmit) sendDesktop("pet-animation", motion);
  for (const button of document.querySelectorAll("[data-pet-motion]:not(html)")) {
    button.setAttribute("aria-pressed", String(button.dataset.petMotion === motion));
  }
  if (motion !== "idle") {
    motionTimer = setTimeout(() => setMotion("idle", false), motion === "dance" ? 4400 : 3300);
  }
}

export function setupDesktop({ onConnection, onTheme, onReference, onNotice }) {
  referenceChanged = onReference;
  root.dataset.desktopNative = String(Boolean(desktopBridge));
  root.dataset.desktopVisible = "true";
  const petDialog = element("desktop-pet-dialog");
  const referenceDialog = element("desktop-reference-dialog");
  let previousActivity;
  let previousTheme = root.dataset.colorMode;
  let lastSize = 100;
  let sizeFrame = 0;

  element("desktop-pet-settings").addEventListener("click", () => petDialog.showModal());
  element("desktop-new-chat").addEventListener("click", () => element("new-chat").click());
  for (const button of document.querySelectorAll("[data-desktop-action]")) {
    button.addEventListener("click", () => {
      if (!desktopBridge) {
        const action = button.dataset.desktopAction;
        if (action === "open-browser") window.open("https://baby-voice.onrender.com/", "_blank", "noopener");
        else onNotice("Open the Windows BABY app to use this control.");
        return;
      }
      const action = button.dataset.desktopAction;
      if (action === "pet-hide" || action === "pet-quit") petDialog.close();
      sendDesktop(action);
    });
  }
  for (const button of document.querySelectorAll("[data-pet-motion]:not(html)")) {
    button.addEventListener("click", () => setMotion(button.dataset.petMotion));
  }
  const range = element("desktop-pet-size");
  range.addEventListener("input", () => {
    const nextSize = Number(range.value);
    setPetSize(nextSize);
    cancelAnimationFrame(sizeFrame);
    sizeFrame = requestAnimationFrame(() => {
      if (nextSize === lastSize) return;
      lastSize = nextSize;
      sendDesktop("pet-size", nextSize);
    });
  });
  element("desktop-reference-clear").addEventListener("click", clearDesktopReference);
  element("desktop-reference-review").addEventListener("click", () => {
    if (!pendingReference) return;
    element("desktop-reference-editor").value = pendingReference.text;
    referenceDialog.showModal();
    element("desktop-reference-editor").focus();
  });
  element("desktop-reference-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const text = element("desktop-reference-editor").value.trim();
    if (pendingReference && text) pendingReference.text = text.slice(0, 12000);
    else pendingReference = null;
    referenceDialog.close();
    renderReference();
    element("draft").focus();
  });
  referenceDialog.addEventListener("close", () => {
    element("desktop-reference-editor").value = "";
  });
  setPetSize(100);
  setMotion("idle", false);
  if (!desktopBridge) return;

  desktopBridge.addEventListener("message", ({ data }) => {
    switch (data?.type) {
      case "desktop-config":
        if (typeof data.size === "number") {
          setPetSize(data.size);
          lastSize = Number(range.value);
        }
        if (data.theme === "light" || data.theme === "dark") {
          previousTheme = data.theme;
          if (root.dataset.colorMode !== data.theme) onTheme(data.theme);
        }
        if (typeof data.server === "string") element("desktop-connection-state").setAttribute("aria-description", data.server);
        break;
      case "desktop-pet":
        if (typeof data.size === "number") {
          setPetSize(data.size);
          lastSize = Number(range.value);
        }
        break;
      case "connection-changed":
        onConnection({ replace: true });
        break;
      case "desktop-status":
        setDesktopConnection(data);
        break;
      case "desktop-reference":
        if (typeof data.text !== "string" || !data.text.trim()) break;
        pendingReference = {
          title: typeof data.title === "string" ? data.title.slice(0, 130) : "Screen context",
          text: data.text.trim().slice(0, 12000),
        };
        renderReference();
        element("draft").focus();
        break;
      case "desktop-notice":
        if (typeof data.text === "string") onNotice(data.text.slice(0, 300));
        break;
      case "desktop-visible": {
        const visible = data.visible === true;
        const wasVisible = root.dataset.desktopVisible === "true";
        root.dataset.desktopVisible = String(visible);
        window.dispatchEvent(new CustomEvent("baby:desktop-visible", { detail: { visible } }));
        if (visible && !wasVisible) onConnection();
        break;
      }
      default:
        break;
    }
  });

  const activity = () => {
    const state = element("main").dataset.state;
    if (state === previousActivity) return;
    previousActivity = state;
    sendDesktop("activity", state);
  };
  new MutationObserver(activity).observe(element("main"), { attributes: true, attributeFilter: ["data-state"] });
  new MutationObserver(() => {
    if (root.dataset.colorMode === previousTheme) return;
    previousTheme = root.dataset.colorMode;
    sendDesktop("theme", previousTheme);
  }).observe(root, { attributes: true, attributeFilter: ["data-color-mode"] });
  activity();
  sendDesktop("ready");
  onConnection();
}
