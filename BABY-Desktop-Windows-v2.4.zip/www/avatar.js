import * as THREE from "./vendor/three.module.min.js";

const poses = {
  wave: { length: 2.1, speed: 10 },
  walk: { length: 3.4, speed: 10 },
  dance: { length: 4.5, speed: 12 },
};

function roundedShape(width, height, radius) {
  const x = -width / 2;
  const y = -height / 2;
  const r = Math.min(radius, width / 2, height / 2);
  const shape = new THREE.Shape();
  shape.moveTo(x + r, y);
  shape.lineTo(x + width - r, y);
  shape.quadraticCurveTo(x + width, y, x + width, y + r);
  shape.lineTo(x + width, y + height - r);
  shape.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
  shape.lineTo(x + r, y + height);
  shape.quadraticCurveTo(x, y + height, x, y + height - r);
  shape.lineTo(x, y + r);
  shape.quadraticCurveTo(x, y, x + r, y);
  return shape;
}

function reflectionTexture(renderer) {
  const canvas = document.createElement("canvas");
  canvas.width = 256;
  canvas.height = 128;
  const context = canvas.getContext("2d");
  if (!context) return null;
  context.fillStyle = "#455776";
  context.fillRect(0, 0, 256, 128);
  const sky = context.createLinearGradient(0, 0, 0, 128);
  sky.addColorStop(0, "#8499bd");
  sky.addColorStop(.58, "#263955");
  sky.addColorStop(1, "#040a1b");
  context.fillStyle = sky;
  context.fillRect(0, 0, 256, 128);
  context.fillStyle = "#f0f7ff";
  context.fillRect(34, 20, 43, 44);
  context.fillStyle = "#92c5ff";
  context.fillRect(157, 16, 13, 67);
  context.fillStyle = "#ecf7ff";
  context.fillRect(188, 25, 21, 39);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.mapping = THREE.EquirectangularReflectionMapping;
  const generator = new THREE.PMREMGenerator(renderer);
  const environment = generator.fromEquirectangular(texture);
  generator.dispose();
  texture.dispose();
  return environment;
}

function createRobot(scene) {
  const root = new THREE.Group();
  scene.add(root);
  const pearl = new THREE.MeshPhysicalMaterial({
    color: 0xe3eef9, metalness: .32, roughness: .27, clearcoat: .8, clearcoatRoughness: .19,
  });
  const blue = new THREE.MeshPhysicalMaterial({
    color: 0x2d6fc8, roughness: .23, metalness: .54, clearcoat: .75, clearcoatRoughness: .15,
  });
  const chrome = new THREE.MeshStandardMaterial({ color: 0x7798ba, metalness: .81, roughness: .26 });
  const graphite = new THREE.MeshPhysicalMaterial({
    color: 0x071324, metalness: .31, roughness: .19, clearcoat: 1, clearcoatRoughness: .12,
  });
  const visorGlass = new THREE.MeshPhysicalMaterial({
    color: 0x0a2948, metalness: .28, roughness: .22, clearcoat: 1, clearcoatRoughness: .13,
  });
  const ice = new THREE.MeshStandardMaterial({
    color: 0xbdeeff, emissive: 0x34c7ff, emissiveIntensity: 1.8, roughness: .31,
  });
  const mesh = (parent, geometry, material, x = 0, y = 0, z = 0) => {
    const part = new THREE.Mesh(geometry, material);
    part.position.set(x, y, z);
    parent.add(part);
    return part;
  };
  const sphere = new THREE.SphereGeometry(1, 36, 24);
  const capsule = (parent, material, position, scale) => {
    const part = mesh(parent, sphere, material, ...position);
    part.scale.set(...scale);
    return part;
  };
  const bevel = (parent, w, h, radius, depth, material, z) => mesh(parent,
    new THREE.ExtrudeGeometry(roundedShape(w, h, radius), {
      depth, bevelEnabled: true, bevelThickness: .045, bevelSize: .046, bevelSegments: 4, curveSegments: 10, steps: 1,
    }), material, 0, 0, z);
  const torus = (parent, radius, tube, material, x, y, z) =>
    mesh(parent, new THREE.TorusGeometry(radius, tube, 12, 40), material, x, y, z);

  const body = new THREE.Group();
  body.position.set(0, 1.16, 0);
  root.add(body);
  capsule(body, chrome, [0, .05, 0], [.63, .57, .46]);
  capsule(body, pearl, [0, .07, .032], [.6, .56, .44]);
  const bodyBelt = torus(body, .43, .02, blue, 0, -.11, 0);
  bodyBelt.rotation.x = Math.PI / 2;
  bodyBelt.scale.set(1.28, 1, 1);
  capsule(body, graphite, [0, .05, .443], [.175, .129, .045]);
  capsule(body, ice, [0, .053, .484], [.084, .065, .018]);

  const arms = [-1, 1].map(side => {
    const arm = new THREE.Group();
    arm.position.set(.54 * side, .25, 0);
    arm.rotation.z = .32 * side;
    body.add(arm);
    capsule(arm, blue, [0, 0, 0], [.147, .144, .144]);
    capsule(arm, pearl, [0, -.26, .025], [.127, .301, .143]);
    capsule(arm, chrome, [0, -.51, .047], [.102, .12, .111]);
    return arm;
  });
  const feet = [-1, 1].map(side => {
    const leg = new THREE.Group();
    leg.position.set(.305 * side, -.37, 0);
    body.add(leg);
    capsule(leg, chrome, [0, -.19, .005], [.125, .23, .13]);
    capsule(leg, blue, [0, -.41, .12], [.213, .107, .29]);
    capsule(leg, pearl, [0, -.38, .108], [.203, .11, .266]);
    return leg;
  });
  const head = new THREE.Group();
  head.position.set(0, 2.13, 0);
  root.add(head);
  capsule(root, chrome, [0, 1.64, 0], [.26, .17, .24]);
  capsule(head, chrome, [0, 0, -.075], [1.015, .691, .635]);
  capsule(head, pearl, [0, .026, -.02], [.996, .681, .648]);
  bevel(head, 1.64, .87, .33, .09, blue, .49);
  bevel(head, 1.536, .758, .3, .085, graphite, .567);
  bevel(head, 1.425, .665, .258, .035, visorGlass, .65);
  for (const side of [-1, 1]) {
    const earpiece = capsule(head, chrome, [side * .955, .026, -.015], [.173, .32, .284]);
    earpiece.rotation.y = side * .13;
    capsule(head, blue, [side * 1.057, .025, -.008], [.105, .268, .238]);
    const lamp = torus(head, .182, .021, ice, side * 1.115, .022, -.012);
    lamp.rotation.y = Math.PI / 2;
    lamp.scale.set(1, 1.11, 1);
  }
  capsule(head, blue, [0, .665, 0], [.163, .083, .134]);
  capsule(head, chrome, [0, .782, 0], [.035, .115, .034]);
  capsule(head, ice, [0, .906, 0], [.086, .083, .086]);
  const eyes = [-1, 1].map(side => mesh(head, new THREE.CapsuleGeometry(.056, .104, 6, 16),
    ice, side * .29, .073, .753));
  const smilePath = new THREE.QuadraticBezierCurve3(new THREE.Vector3(-.1, 0, 0),
    new THREE.Vector3(0, -.115, 0), new THREE.Vector3(.1, 0, 0));
  const smile = mesh(head, new THREE.TubeGeometry(smilePath, 22, .0145, 8, false), ice, 0, -.092, .754);
  const speech = capsule(head, ice, [0, -.131, .756], [.08, .025, .012]);
  speech.visible = false;
  const accent = new THREE.MeshBasicMaterial({
    color: 0xa9e8ff, transparent: true, opacity: .36, depthWrite: false,
  });
  const shine = capsule(head, accent, [-.287, .259, .742], [.315, .022, .006]);
  shine.rotation.z = -.08;
  return { root, head, body, arms, feet, eyes, smile, speech, ice };
}

function createStage(scene) {
  const shadowMaterial = new THREE.MeshBasicMaterial({ color: 0x0c2651, transparent: true, opacity: .18, depthWrite: false });
  const floor = new THREE.Mesh(new THREE.CircleGeometry(1.3, 56), shadowMaterial);
  floor.rotation.x = -Math.PI / 2;
  floor.scale.set(1, .66, 1);
  floor.position.set(0, .016, 0);
  scene.add(floor);
  const platformInk = new THREE.MeshBasicMaterial({ color: 0x66cbff, transparent: true, opacity: .63 });
  const fineInk = new THREE.MeshBasicMaterial({ color: 0x9edcff, transparent: true, opacity: .3 });
  const rings = [[1.17, .018], [1.36, .009]].map(([radius, width], index) => {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(radius, width, 8, 65), index ? fineInk : platformInk);
    ring.rotation.x = -Math.PI / 2;
    ring.scale.y = .76;
    ring.position.y = .04;
    scene.add(ring);
    return ring;
  });
  const field = new THREE.BufferGeometry();
  const points = new Float32Array(44 * 3);
  for (let i = 0; i < 44; i++) {
    points[i * 3] = Math.sin(i * 29.13) * (1.15 + (i % 9) * .14);
    points[i * 3 + 1] = .2 + (i * 1.719 % 3.1);
    points[i * 3 + 2] = -1.2 - (i % 8) * .18;
  }
  field.setAttribute("position", new THREE.BufferAttribute(points, 3));
  const sparkInk = new THREE.PointsMaterial({ color: 0x8bd5ff, size: .041, transparent: true, opacity: .6 });
  const sparks = new THREE.Points(field, sparkInk);
  scene.add(sparks);
  const arcMaterial = new THREE.MeshBasicMaterial({ color: 0x6fc6ff, transparent: true, opacity: .23 });
  const arc = new THREE.Mesh(new THREE.TorusGeometry(1.25, .009, 8, 64, 4.1), arcMaterial);
  arc.rotation.z = .42;
  arc.position.set(0, 1.73, -1.17);
  scene.add(arc);
  return { floor, rings, sparks, arc };
}

export function mountAvatar(stage) {
  if (!stage) return () => {};
  const canvas = document.createElement("canvas");
  canvas.className = "baby-webgl";
  canvas.setAttribute("aria-hidden", "true");
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, powerPreference: "low-power" });
  } catch {
    return () => {};
  }
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(33, 1, .1, 25);
  camera.position.set(.06, 1.6, 6.8);
  camera.lookAt(0, 1.51, 0);
  renderer.setClearColor(0x000000, 0);
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.22;
  let reflections;
  try {
    reflections = reflectionTexture(renderer);
    if (reflections) scene.environment = reflections.texture;
  } catch { /* The directional lighting also works without a reflection texture. */ }
  const fill = new THREE.HemisphereLight(0xe3f3ff, 0x223d6e, 2.85);
  const key = new THREE.DirectionalLight(0xf4faff, 2.7);
  key.position.set(-4, 6, 5);
  const rim = new THREE.DirectionalLight(0x55adff, 3.8);
  rim.position.set(4, 2, -4);
  scene.add(fill, key, rim);
  const model = createRobot(scene);
  const platform = createStage(scene);
  const root = document.documentElement;
  const main = document.getElementById("main");
  const reduce = matchMedia("(prefers-reduced-motion: reduce)");
  const pointer = new THREE.Vector2();
  let heading = 0, tilt = 0, drag, frame = 0, last = 0, started = 0, mode = "idle", modeAt = 0;
  let alive = true, onscreen = true, contextLost = false, hostVisible = true, lastTheme = "";
  stage.tabIndex = 0;
  stage.setAttribute("role", "button");
  stage.setAttribute("aria-label", "BABY in 3D. Drag to rotate, or press Enter to wave.");
  stage.prepend(canvas);

  function resize() {
    if (!alive || !stage.clientWidth || !stage.clientHeight) return;
    const width = stage.clientWidth;
    const height = stage.clientHeight;
    camera.aspect = width / height;
    camera.fov = camera.aspect < .85 ? 41 : 33;
    camera.updateProjectionMatrix();
    renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.55));
    renderer.setSize(width, height, false);
    wake();
  }

  function choose(next, now) {
    mode = poses[next] ? next : "idle";
    modeAt = now;
    wake();
  }

  function draw(now) {
    frame = 0;
    if (!alive || contextLost || !onscreen || !hostVisible || document.hidden) return;
    if (!started) started = now;
    if (!reduce.matches && now - last < 24) { wake(); return; }
    last = now;
    const t = reduce.matches ? 0 : (now - started) / 1000;
    const activePose = poses[mode];
    const progress = (now - modeAt) / 1000;
    const move = activePose && !reduce.matches && progress < activePose.length
      ? Math.min(1, progress * 6, (activePose.length - progress) * 4) : 0;
    const phase = activePose ? progress * activePose.speed : 0;
    if (!move && activePose && progress >= activePose.length) mode = "idle";
    const state = main?.dataset.state || "idle";
    const theme = root.dataset.background + "/" + root.dataset.colorMode;
    if (lastTheme !== theme) {
      lastTheme = theme;
      const light = root.dataset.colorMode !== "dark";
      const glacier = root.dataset.background === "glacier";
      rim.color.set(glacier ? 0x65dbe0 : 0x5babff);
      fill.color.set(light ? 0xebf7ff : 0xbad9ff);
      renderer.toneMappingExposure = light ? 1.15 : 1.32;
      platform.sparks.material.opacity = light ? .43 : .76;
      platform.floor.material.opacity = light ? .2 : .29;
    }
    const speaking = state === "speaking";
    const listening = state === "listening";
    const thinking = state === "thinking";
    const movement = move * Math.sin(phase);
    const dance = mode === "dance" ? move : 0;
    const walk = mode === "walk" ? move : 0;
    const wave = mode === "wave" ? move : 0;
    model.root.position.x = (dance ? movement * .26 : 0) + (walk ? Math.sin(progress * 2.1) * walk * .36 : 0);
    model.root.position.y = t ? (.044 * Math.sin(2.35 * t) + Math.abs(movement) * (walk ? .11 : dance ? .16 : .018)) : 0;
    const targetX = tilt - pointer.y * .12;
    const targetY = heading + pointer.x * .16 + dance * Math.sin(phase * .59) * .45 + (t ? Math.sin(t * .69) * .07 : 0);
    model.root.rotation.x = THREE.MathUtils.lerp(model.root.rotation.x, targetX, .17);
    model.root.rotation.y = THREE.MathUtils.lerp(model.root.rotation.y, targetY, .17);
    model.root.rotation.z = movement * (dance ? .14 : walk ? .07 : .025);
    model.head.rotation.x = (thinking ? .13 : 0) + (t ? Math.sin(t * 3.1) * (speaking ? .065 : .032) : 0);
    model.head.rotation.z = (listening ? .16 : 0) + (t ? Math.sin(1.12 * t) * .033 : 0) - dance * Math.sin(phase) * .1;
    model.arms[0].rotation.x = walk * Math.sin(phase) * .71;
    model.arms[1].rotation.x = -walk * Math.sin(phase) * .71;
    model.arms[0].rotation.z = -.37 - dance * (.4 + .65 * Math.sin(phase * .7));
    model.arms[1].rotation.z = .37 + dance * (.4 - .65 * Math.sin(phase * .7)) + wave * (1.7 + .4 * Math.sin(phase));
    model.feet[0].rotation.x = movement * (walk ? .81 : .41 * dance);
    model.feet[1].rotation.x = -model.feet[0].rotation.x;
    const blink = t > 0 ? Math.max(0, 1 - Math.abs((t + .76) % 4.85 - 4.68) * 17) : 0;
    for (const eye of model.eyes) eye.scale.y = Math.max(.12, (listening ? 1.29 : thinking ? .72 : 1) * (1 - blink * .94));
    model.smile.visible = !speaking;
    model.smile.scale.y = thinking ? .36 : 1;
    model.speech.visible = speaking;
    model.speech.scale.y = .025 + Math.abs(Math.sin(t * 16)) * .035;
    model.ice.emissiveIntensity = (listening ? 2.45 : 1.82) + Math.abs(Math.sin(t * 2.5)) * .27;
    platform.sparks.rotation.y = t * .051;
    platform.sparks.position.y = Math.sin(t * .65) * .11;
    platform.arc.rotation.z = .42 + t * .14;
    platform.rings[0].material.opacity = .54 + Math.sin(t * 2) * .13;
    renderer.render(scene, camera);
    if (!reduce.matches) wake();
  }

  function wake() {
    if (alive && !frame && !contextLost && onscreen && hostVisible && !document.hidden) frame = requestAnimationFrame(draw);
  }

  function movePointer(event) {
    const rect = stage.getBoundingClientRect();
    pointer.x = THREE.MathUtils.clamp((event.clientX - rect.left) / rect.width * 2 - 1, -1, 1);
    pointer.y = THREE.MathUtils.clamp((event.clientY - rect.top) / rect.height * 2 - 1, -1, 1);
    if (drag) {
      heading = THREE.MathUtils.clamp(drag.heading + (event.clientX - drag.x) * .013, -1.36, 1.36);
      tilt = THREE.MathUtils.clamp(drag.tilt + (event.clientY - drag.y) * .009, -.43, .33);
    }
    wake();
  }

  const events = new AbortController();
  const signal = { signal: events.signal };
  stage.addEventListener("pointermove", movePointer, signal);
  stage.addEventListener("pointerdown", event => {
    if (event.button !== 0) return;
    drag = { x: event.clientX, y: event.clientY, heading, tilt };
    stage.setPointerCapture(event.pointerId);
  }, signal);
  stage.addEventListener("pointerup", event => {
    if (drag && Math.hypot(event.clientX - drag.x, event.clientY - drag.y) < 5) choose("wave", performance.now());
    drag = null;
  }, signal);
  stage.addEventListener("pointercancel", () => { drag = null; }, signal);
  stage.addEventListener("pointerleave", () => { pointer.set(0, 0); wake(); }, signal);
  stage.addEventListener("keydown", event => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      heading = tilt = 0;
      choose("wave", performance.now());
    } else if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
      event.preventDefault();
      heading = THREE.MathUtils.clamp(heading + (event.key === "ArrowLeft" ? -.16 : .16), -1.36, 1.36);
      wake();
    }
  }, signal);
  canvas.addEventListener("webglcontextlost", event => {
    event.preventDefault();
    contextLost = true;
    delete stage.dataset.webgl;
  }, signal);
  canvas.addEventListener("webglcontextrestored", () => {
    contextLost = false;
    stage.dataset.webgl = "ready";
    wake();
  }, signal);
  document.addEventListener("visibilitychange", wake, signal);
  window.addEventListener("baby:desktop-visible", event => {
    hostVisible = event.detail?.visible !== false;
    wake();
  }, signal);
  reduce.addEventListener("change", wake, signal);
  const attributes = new MutationObserver(records => {
    if (records.some(record => record.attributeName === "data-pet-motion"))
      choose(root.dataset.petMotion || "idle", performance.now());
    wake();
  });
  attributes.observe(root, { attributes: true, attributeFilter: ["data-pet-motion", "data-background", "data-color-mode"] });
  if (main) attributes.observe(main, { attributes: true, attributeFilter: ["data-state"] });
  const intersection = new IntersectionObserver(entries => { onscreen = entries[0].isIntersecting; wake(); });
  intersection.observe(stage);
  const sizing = new ResizeObserver(resize);
  sizing.observe(stage);
  stage.dataset.webgl = "ready";
  resize();

  return () => {
    alive = false;
    events.abort();
    attributes.disconnect();
    intersection.disconnect();
    sizing.disconnect();
    if (frame) cancelAnimationFrame(frame);
    const disposed = new Set();
    scene.traverse(part => {
      for (const resource of [part.geometry, part.material]) {
        if (resource && !disposed.has(resource)) {
          disposed.add(resource);
          resource.dispose();
        }
      }
    });
    reflections?.dispose();
    renderer.dispose();
    canvas.remove();
    delete stage.dataset.webgl;
  };
}
