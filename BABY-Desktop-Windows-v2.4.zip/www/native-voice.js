import { createVoice as browserVoice } from "./browser-voice.js";
import { desktopBridge } from "./desktop.js";

export function createVoice(options = {}) {
  if (!desktopBridge) return browserVoice(options);
  const { onState = () => {}, onTranscript = () => {}, onError = () => {} } = options;
  const voiceListeners = new Set();
  let canListen = false;
  let canSpeak = false;
  let voices = [];
  let sequence = 0;
  let state = "idle";
  let session;

  function setState(next) {
    if (next === state) return;
    state = next;
    onState(state);
  }

  function finish() {
    session = undefined;
    setState("idle");
  }

  function stopSpeaking() {
    if (session?.kind !== "speaking") return;
    desktopBridge.postMessage({ action: "speech-stop", id: session.id });
    finish();
  }

  function stopListening() {
    if (session?.kind !== "listening" || session.stopping) return;
    session.stopping = true;
    desktopBridge.postMessage({ action: "speech-stop-listen", id: session.id });
  }

  function cancelListening() {
    if (session?.kind !== "listening") return;
    desktopBridge.postMessage({ action: "speech-stop-listen", id: session.id, cancel: true });
    finish();
  }

  function startListening() {
    if (!canListen) { onError("recognition-unsupported"); return false; }
    if (session?.kind === "listening") return false;
    stopSpeaking();
    session = { kind: "listening", id: "voice-" + (++sequence) };
    setState("listening");
    desktopBridge.postMessage({ action: "speech-listen", id: session.id });
    return true;
  }

  function speak(text, _language, { voiceURI = "", rate = 1 } = {}) {
    if (!canSpeak) { onError("synthesis-unsupported"); return false; }
    if (typeof text !== "string" || !text.trim()) return false;
    cancelListening();
    stopSpeaking();
    session = { kind: "speaking", id: "voice-" + (++sequence) };
    setState("speaking");
    desktopBridge.postMessage({
      action: "speech-speak",
      id: session.id,
      text: text.trim().slice(0, 20000),
      rate: Number.isFinite(rate) ? Math.min(1.35, Math.max(.7, rate)) : 1,
      voiceURI,
    });
    return true;
  }

  desktopBridge.addEventListener("message", ({ data }) => {
    if (data?.type === "desktop-config") {
      canListen = data.canListen === true;
      canSpeak = data.canSpeak === true;
      voices = Array.isArray(data.voices)
        ? data.voices.filter((voice) => typeof voice?.lang === "string" && typeof voice?.name === "string" && typeof voice?.voiceURI === "string")
        : [];
      for (const listener of voiceListeners) listener(voices);
      return;
    }
    if (data?.type === "desktop-voice-reset") {
      const listening = session?.kind === "listening";
      finish();
      if (listening) onError("aborted");
      return;
    }
    if (data?.type !== "desktop-voice" || !session || data.id !== session.id) return;
    const listening = session.kind === "listening";
    if (data.event === "ended") {
      finish();
    } else if (data.event === "transcript" && listening) {
      finish();
      const text = typeof data.text === "string" ? data.text.trim() : "";
      if (text) onTranscript(text, { final: true });
      else onError("no-speech");
    } else if (data.event === "error") {
      const detail = typeof data.reason === "string" ? data.reason : "";
      finish();
      const code = listening ? /permission|access|denied/i.test(detail) ? "not-allowed"
        : /device|microphone/i.test(detail) ? "audio-capture" : "recognition-failed" : "speech-failed";
      onError(code, { reason: detail });
    }
  });

  return {
    get canListen() { return canListen; },
    get canSpeak() { return canSpeak; },
    startListening, stopListening, cancelListening, speak, stopSpeaking,
    getVoices: () => voices,
    onVoicesChanged(listener) {
      voiceListeners.add(listener);
      return () => voiceListeners.delete(listener);
    },
  };
}
