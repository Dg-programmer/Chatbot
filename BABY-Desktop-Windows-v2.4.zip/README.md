# BABY Desktop

BABY Desktop is a portable Windows 10/11 app. A single animated pet stays above your browsers and other ordinary desktop windows. You can drag it between monitors. Its companion panel uses BABY’s web chat with a live Three.js scene.

## Open BABY

1. Exit the previous desktop version from its tray menu, if it is running. Extract the portable ZIP into a folder, keep its files together, and run **BABY-Desktop.exe** from that folder. Windows needs the Microsoft Edge WebView2 Runtime for the 3D panel.
2. Click BABY and select **Connection**. The app defaults to [your hosted BABY](https://baby-voice.onrender.com/). Enter your **BABY owner password**, then click **Connect**. The Gemini key stays on the server. **Stay signed in on this PC** stores a Windows-encrypted session for this server in your Windows user profile.
3. Send a message. **Mic** puts an English dictation in the message box for you to review, **Speaker** toggles automatic spoken replies, and **Replay** reads the latest reply. These controls use your Windows microphone and installed English speech components.

To connect to a running local BABY instead, enter `http://127.0.0.1:4173` in **Connection** and leave the password blank.

## Work anywhere on the desktop

- Drag the pet onto any connected monitor. The open chat panel follows the pet and moves to the side with space. Transparent space around the pet passes clicks through to the window beneath it.
- Open the desktop pet controls to adjust its size or choose **Walk**, **Dance**, or **Wave**. You can rotate the 3D pet in the chat by dragging it. The floating pet also responds to listening, thinking, and speaking.
- Use **Light** or **Dark** in the chat header to change the appearance. BABY remembers your choice.
- Click BABY once to open chat and again to hide the panel completely. The hidden panel leaves Alt+Tab and keeps your current conversation ready for the next click. The panel’s **X** hides it too. **Chats** opens the conversation list and **New chat** starts a separate thread.
- Left-click BABY’s icon in the Windows notification area to restore the pet and chat. If the icon is in the overflow area, click the **^** near the clock first. You can also open **BABY Desktop** from the Start menu or press **Ctrl+Alt+B** when the shortcut is available. Right-click the pet or tray icon for **Hide BABY**, **Show BABY**, and **Quit BABY**. Hide keeps BABY running in the tray. Quit closes the app.
- Use **Screen** to read the visible text on the display containing the pet. Move BABY to the display you want first. The app temporarily hides its own windows, recognizes text on your device, and shows an editable preview. Only the text you approve is included when you send the next message. Screen capture does not run in the background and does not save a screenshot.
- The paperclip uploads images (PNG, JPEG, WebP), PDFs, text documents and data files (TXT, Markdown, CSV, TSV, JSON), and audio (MP3, WAV, OGG, FLAC) to the hosted Gemini connection for analysis. Attach up to three files per message, with a limit of 8 MiB per file and 12 MiB combined. Export Office documents to PDF before attaching them. **Text file** previews and lets you edit up to 12,000 characters from a local TXT, Markdown, CSV, TSV, JSON, or LOG file before sending.

Windows keeps the overlay within the regular desktop session. The lock screen, secure system prompts, and some exclusive full-screen apps are outside that session. If Render is waking from idle, the first connection can take about a minute. Conversations are stored in BABY Desktop’s WebView2 profile.

## Build from source

From the project root on 64-bit Windows with Node.js, the .NET Framework compiler and Developer Pack:

~~~powershell
.\desktop\Build-Desktop.ps1
~~~

The script writes `desktop/bin/BABY-Desktop.exe`, the local web assets, and WebView2 libraries. It uses pinned, checksum-verified WebView2 and Three.js packages. The portable build can connect directly to hosted BABY. Windows provides the speech and OCR components.
